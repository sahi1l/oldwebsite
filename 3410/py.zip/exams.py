import archive
def out():
    examresult=['<div id="exams"<h2>Exams</h2><TABLE BORDER=1>\n<TR><TH>&nbsp;<TH COLSPAN=2>Review<TH>Exam']
    examQ=False
    for i in xrange(1,6):
        result=''
        result+=archive.Qlink('Exam'+str(i)+'Outline.pdf','Review Outline',pfx='<TD>')
        result+=archive.Qlink('SampleExam'+str(i)+'.pdf','Sample Exam',pfx='<TD>')
        result+=archive.Qlink('SampleExam'+str(i)+'S.pdf','(solutions)',pfx='<BR>')
        if(result != ''):
            examQ=True
            examresult.append('<TR><TD>Exam '+str(i)+':'+result+'\n')
    if examQ:
        examresult.append('</TABLE></DIV>')
        return '\n'.join(examresult)
    return ''
    
