#!/usr/bin/env python
import intro
import news
import assignments
I=open("index.html","w")
I.write(intro.out("Thermal Physics","Physics 3410","Spring 2016","red.css"))
I.write(assignments.out(["Monday","Wednesday","Friday"]))
I.write(news.out())
I.close()

