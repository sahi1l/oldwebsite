def out(name,number,semester,css):
    result='''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="lib/index.css">
<link rel="stylesheet" type="text/css" href="lib/%(css)s">
<SCRIPT SRC="lib/jquery.js"></SCRIPT>
<SCRIPT SRC="lib/grades.js"></SCRIPT>
<link href="http://fonts.googleapis.com/css?family=Lato:400,300" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Shadows+Into+Light+Two" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>University of Toledo %(number)s, %(semester)s</title>
<body>
<DIV id="utoledo">
<A HREF="http://www.utoledo.edu">University&nbsp;of&nbsp;Toledo</A>
 <img src="img/utlogo.png" alt="" height="20" style="vertical-align:middle"/>
<A HREF="http://www.utoledo.edu/nsm/physast/index.html">
  Department&nbsp;of&nbsp;Physics&nbsp;&amp;&nbsp;Astronomy
</A>
</DIV>
<div style="display:inline-block;">
<div class="class">
<h1 id="number">%(number)s</h1>
<p id="name">%(name)s</p>
<p id="semester">%(semester)s</p>
</div>
<DIV id="professor">
<h2>Instructor</h2>
<DIV id="myname">
Scott A. Hill, Ph.D.</DIV>
  <UL>
  <LI><B>Phone/SMS</B> (567) 343-2284
  <LI><B>Email</B> scott.hill@utoledo
  <LI><B>AIM</B> doogadgit
  <LI><B>Google Chat</B> physhill
  <LI><B>Office</B> MH 4019
</UL>
</DIV>
<br/>
<div id="middle">
<div id="syllabus"> <a href="Syllabus/index.html">Syllabus</a></div>
<div id="gradeframe">
  <h2>Grades: </h2>
  <label for="gradeid"> Enter your grade ID:</label>
  <INPUT TYPE="text" size=4 name="id" id="gradeid">
  <BUTTON onclick="GetGrade()">Get grades</BUTTON>
  <BR/><DIV id="grades"></DIV>
</div>
</div>
</div>
''' % {"name":name,"number":number,"semester":semester,"css":css}
    return result
