import os.path
dir='archive'; #what to append to link to get a local file, maybe points to another server
def link(L,text):
    if not (L[0:1]==':' or L[0:7]=='http://'):
        L=dir+'/'+L
    return '<A HREF="'+L+'">'+text+'</A>'

def exists(L):
    #really check for the file or in list.txt
    fname=dir+'/'+L
    return os.path.isfile(fname) 

def Qlink(L,text,pfx='',otherwise=''):
    #similar to link, but returns "" if file does not exist/is not in list.txt
    if exists(L):
        return pfx+link(L,text)
    else:
        return otherwise
