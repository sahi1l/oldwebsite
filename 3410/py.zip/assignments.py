import archive
import re
import datetime
import exams
shortdays={'Monday':'M','Tuesday':'T','Wednesday':'W','Thursday':'R','Friday':'F'}
def out(days):
    result=header(days)
    F=open('assignments.txt','r')
    Wk=0
    current=1
    today=datetime.date.today()
    topic={};
    date={}
    chapter={}
    HW={}
    Qz={}
    for ln in F:
        if(ln.strip()==''):
            break; #A line break says don't go any more
        Wk+=1
        ln=re.sub('\t+','\t',ln).strip()
        Ln=(ln+('\t'*5)).split('\t')
        topic[Wk]=re.sub('; *','<BR>',Ln[1])
        date[Wk]=Ln[0]
        splitdate=date[Wk].split('/')
        thedate=datetime.date.today()
        thedate=thedate.replace(month=int(splitdate[0]),day=int(splitdate[1]))
        daysbefore=(thedate-today).days
        if daysbefore>=0 and daysbefore<7:
            current=Wk
        chapter[Wk]=Ln[2]
        HW[Wk]=Ln[3]
        Qz[Wk]=Ln[4]
    url=''
    for wk in range(Wk,0,-1):
        media=''
        for longday in days:
            day=shortdays.get(longday,'X')
            media+='<TD>\n\t'
            media+=archive.Qlink(day+str(wk)+'.pdf','written',otherwise='&nbsp;')
            media+='<BR>\n\t'
            media+=archive.Qlink(day+str(wk)+'.mp3','audio',otherwise='&nbsp;')
            media+='\n'
        if(Wk==current):
           result+='<TR class="current">'
        else:
            result+='<TR>'
        result+='<TD class="weeknumber">'+str(wk)+'\n'
        result+='<TD class="date">'+date[wk]+'\n'
        result+='<TD class="topic">'+topic[wk]+'\t'
        result+='<TD class="chapter">'+chapter[wk]+'\n'
        result+=archive.Qlink('Week'+str(wk)+'.pdf','Outline',pfx='<BR>')+'\n'

        result+='<TD class="homework">'
        result+=archive.Qlink(HW[wk]+'.pdf',HW[wk],otherwise='&nbsp;')+'\n\t<BR>'
        result+=archive.Qlink(HW[wk]+'S.pdf','solutions',otherwise='&nbsp;')+'\n\t'

        result+='<TD class="quiz">'
        if Qz[wk] == 'EXAM':
            result+='<B>Exam</B><BR>\n\t'
        else:
            result+=archive.Qlink(Qz[wk]+'.pdf',Qz[wk],otherwise='&nbsp;')+'\n\t<BR>'
            result+=archive.Qlink(Qz[wk]+'S.pdf','solutions',otherwise='&nbsp;')+'\n\t'
        result+=media
    result+='</TABLE></DIV>\n</DIV>'
    F.close()
    return result


def header(days):
    result=['<div id="assignments">']
    result.append(exams.out())
    result.append('<div id="weekly">')
    result.append('<H2>Weekly Assignments</H2>')
    result.append('<TABLE id="weeklyT">')
    result.append('<TR><TH COLSPAN=2>Week<TH ROWSPAN=2>Topics<BR>Discussed')
    result.append('<TH ROWSPAN=2>Chapters')
    result.append('<TH ROWSPAN=2>Homework<BR>')
    result.append('<TH ROWSPAN=2 class="quiz">Quiz/<BR>Exam<BR>')
    result.append('<TH COLSPAN='+str(len(days))+'>Class Notes')
    result.append('<TR><TH>#<TH>Starting');
    for day in days:
        result.append('<TH>'+day)
    return '\n'.join(result)
