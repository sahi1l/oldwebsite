import re
import archive
def out():
    result=['<div id="news"><h2>News</h2><ul>\n'];
    date="";
    F=open("news.txt","r")
    for ln in F:
        if(ln.strip()==''):
            fresh=1
            continue
        if ln[0:1]=='#':
            continue
        if ln[0:3]=='XXX':
            continue
        search=re.match('^([0-9]+\/[0-9]+:)(.*)$',ln)
        if (search):
            date=search.group(1)
            ln=search.group(2)
        result.append('<li>')
        if date:
            result.append('<DIV class="updated">Posted '+date+'</DIV>')
            date=''
        #Replace lines of the form [link] with href links to local file
        S=re.split('(\[.+?\])',ln); #list like {'This ','[is]',' a ','[testing scenario]'}
        ln=''
        for s in S:
            if s[0:1]=='[':
                sp=s[1:-1].split(' ')
                link=sp[0]
                if len(sp)>1:
                    text=' '.join(sp[1:])
                else:
                    text=link
                ln+=archive.link(link,text)
            else:
                ln+=s
        result.append(ln)
    result.append('</ul></div>')
    F.close()
    return '\n'.join(result)
